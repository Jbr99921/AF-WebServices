//
//  CommonWS.swift
//  SwiftByJayesh
//
//  Created by Jayesh Thummar on 26/07/18.
//  Copyright © 2018 bacancy. All rights reserved.
//

import UIKit
import Alamofire

class CommonWS: NSObject{

    //MARK:- Alamofire
    //MARK:-POST Method
    class func PostURL(url: String, dict:Dictionary<String, Any>, completion: @escaping (_ responceData:Dictionary<String, Any>, _ success: Bool) -> ())
    {
        if SingleTon.isInternetAvailable()
        {
            let fullUrl = MAIN_URL + url
            print("POST API: \(fullUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
            
            //set Headers
            let headers: HTTPHeaders = ["Content-Type": "application/json"]
            
            AF.request(fullUrl, method: .post, parameters: dict, encoding: JSONEncoding.prettyPrinted, headers: headers, interceptor: nil).responseJSON { (response) in
                switch response.result
                {
                case .success(_):
                    if response.value != nil
                    {
                        print(response.value as! NSDictionary)
                        let data = response.value! as Any as! [String:Any]
                        if Int(data["response_code"] as! Int) == 200
                        {
                            completion(data,true)
                        }
                        else
                        {
                            completion(data,false)
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp=NSDictionary.init(object: response.error?.localizedDescription ?? ERROR, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp=NSDictionary.init(object: INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    
    //MARK: GET Method
    class func GetURL(url: String, dict:Dictionary<String, Any>, completion: @escaping (_ responceData:Dictionary<String, Any>, _ success: Bool) -> ())
    {
        if SingleTon.isInternetAvailable()
        {
            let fullUrl = MAIN_URL + url
            print("GET API: \(fullUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
            
            //set Headers
            let headers: HTTPHeaders = ["Content-Type": "application/json"]
            
            AF.request(fullUrl, method: .get, parameters: nil, encoding: JSONEncoding.prettyPrinted, headers: headers).responseJSON { (response) in
                switch response.result
                {
                case .success(_):
                    if response.value != nil
                    {
                        print(response.value as! NSDictionary)
                        let data = response.value! as Any as! [String:Any]
                        if Int(data["response_code"] as! Int) == 200
                        {
                            completion(data,true)
                        }
                        else
                        {
                            completion(data,false)
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp=NSDictionary.init(object: response.error?.localizedDescription ?? ERROR, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp=NSDictionary.init(object: INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    
    //MARK:-PUT Method
    class func PutURL(url: String, dict:Dictionary<String, Any>, completion: @escaping (_ responceData:Dictionary<String, Any>, _ success: Bool) -> ())
    {
        if SingleTon.isInternetAvailable()
        {
            let fullUrl = MAIN_URL + url
            print("PUT API: \(fullUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
         
            //set Headers
            let headers: HTTPHeaders = ["Content-Type": "application/json"]
            
            AF.request(fullUrl, method: .put, parameters: dict, encoding: JSONEncoding.prettyPrinted, headers: headers).responseJSON { (response) in
                switch response.result
                {
                case .success(_):
                    if response.value != nil
                    {
                        print(response.value as! NSDictionary)
                        let data = response.value! as Any as! [String:Any]
                        if Int(data["response_code"] as! Int) == 200
                        {
                            completion(data,true)
                        }
                        else
                        {
                            completion(data,false)
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp=NSDictionary.init(object: response.error?.localizedDescription ?? ERROR, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp=NSDictionary.init(object: INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    //MARK:-DELETE Method
    class func DeleteURL(url: String, dict:Dictionary<String, Any>, completion: @escaping (_ responceData:Dictionary<String, Any>, _ success: Bool) -> ())
    {
        if SingleTon.isInternetAvailable()
        {
            let fullUrl = MAIN_URL + url
            print("DELETE API: \(fullUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
          
            //set Headers
            let headers: HTTPHeaders = ["Content-Type": "application/json"]
            
            AF.request(fullUrl, method: .delete, parameters: dict, encoding: JSONEncoding.prettyPrinted, headers: headers).responseJSON { (response) in
                switch response.result
                {
                case .success(_):
                    if response.value != nil
                    {
                        print(response.value as! NSDictionary)
                        let data = response.value! as Any as! [String:Any]
                        if Int(data["response_code"] as! Int) == 200
                        {
                            completion(data,true)
                        }
                        else
                        {
                            completion(data,false)
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp=NSDictionary.init(object: response.error?.localizedDescription ?? ERROR, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp=NSDictionary.init(object: INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    //MARK:-Upload Multipart Method
    class func PostURLWithMultipart(url: String, dict:Dictionary<String, Any>, imageData: Data, completion: @escaping (_ responceData:Dictionary<String, Any>, _ success: Bool) -> ())
    {
        if SingleTon.isInternetAvailable()
        {
            let fullUrl = MAIN_URL + url
            print("MALTIPART API: \(fullUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
            
            //set Headers
            let headers: HTTPHeaders = ["Content-Type": "image/jpeg"]
            AF.upload(multipartFormData: { (multipartFormData) in
                
                //images
                 multipartFormData.append(imageData, withName: "profile_photo", fileName: "imageProfile.jpg", mimeType: "image/jpg")
                
                //other params
                for (key, value) in dict {
                    if let boolvalue:Bool =  value as? Bool{
                        multipartFormData.append(Bool(boolvalue).description.data(using: .utf8)!, withName: key)
                    }else{
                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                    }
                }
                //Response
            }, to: fullUrl, method: .post, headers: headers).responseJSON(completionHandler: { (response) in
                switch response.result
                {
                case .success(_):
                    if response.value != nil
                    {
                        print(response.value as! NSDictionary)
                        let data = response.value! as Any as! [String:Any]
                        if Int(data["response_code"] as! Int) == 200
                        {
                            completion(data,true)
                        }
                        else
                        {
                            completion(data,false)
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp=NSDictionary.init(object: response.error?.localizedDescription ?? ERROR, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
                //upload progress
            }).uploadProgress { (progrss) in
                 print("Upload Progress: \(progrss.fractionCompleted)")
            }
        }
        else
        {
            let temp=NSDictionary.init(object: INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
}
