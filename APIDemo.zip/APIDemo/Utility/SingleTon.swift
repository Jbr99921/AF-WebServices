//
//  SingleTon.swift
//  SwiftByJayesh
//
//  Created by Jayesh Thummar on 26/07/18.
//  Copyright © 2018 bacancy. All rights reserved.
//

import UIKit
import Reachability
import Contacts

class SingleTon: NSObject {
    static let sharedSingleTon = SingleTon()
    
    class func isInternetAvailable() -> Bool {
        var status: Bool
        let reachability = try! Reachability()
        switch reachability.connection
        {
        case .none:
            debugPrint("Network unreachable")
            status = false
        case .wifi:
            debugPrint("Network reachable through WiFi")
            status = true
        case .cellular:
            status = true
            debugPrint("Network reachable through Cellular Data")
        case .unavailable:
            debugPrint("Network unreachable")
            status = false
        }
        return status
    }
    func getStoryboard() -> UIStoryboard
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        return storyBoard
    }
    
    //MARK:- Custom Alert controlles
    class func showAlertonView(_ superview: UIViewController?, withAlertTitle titlestr: String?, buttonOkTitle buttonTitle: String?, andMessage msg: String?, withHandler handler: @escaping (_ action: UIAlertAction?) -> Void) {
        let alert = UIAlertController(title: titlestr, message: msg, preferredStyle: .alert)
        let okAct = UIAlertAction(title: buttonTitle, style: .cancel, handler: handler)
        alert.addAction(okAct)
        superview?.present(alert, animated: true)
    }
    
    class func showAlertonView(_ superview: UIViewController?, withAlertTitle titlestr: String?, buttonCancelTitle cancelTitle: String?, withCancelationHandler firstHandler: @escaping (_ action: UIAlertAction?) -> Void, btnOtherButtonTitle otherTitle: String?, withOtherHandler otherHandler: @escaping (_ action: UIAlertAction?) -> Void, andMessage msg: String?) {
        let alert = UIAlertController(title: titlestr, message: msg, preferredStyle: .alert)
        let cancelAct = UIAlertAction(title: cancelTitle, style: .default, handler: firstHandler)
        let okAct = UIAlertAction(title: otherTitle, style: .default, handler: otherHandler)
        alert.addAction(cancelAct)
        alert.addAction(okAct)
        superview?.present(alert, animated: true)
    }
}
