//
//  ViewController.swift
//  APIDemo
//
//  Created by Jayesh Thummar on 11/03/20.
//  Copyright © 2020 Bacancy Technology Pvt. Ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func registerUser(_ sender: Any) {
        //MARK:- POST DATA
//        var dictParam = [String: Any]()
//        dictParam["email"] = "mn+8DjIKkjLRE+gVS2tqtw=="
//        dictParam["password"] = "YsbENBHnChHWmZDuVLBILA=="
//        dictParam["device_type"] = "iOS"
//        dictParam["device_token"] = "0dcf2baf8925fc8901293a92545681f886e634830ec61b913b69715af05b159a"
//
//        CommonWS.PostURL(url: LOGIN_API, dict: dictParam) { (response, status) in
//            if status
//            {
//                print(response as NSDictionary)
//            }
//            else
//            {
//                SingleTon.showAlertonView(self.view.window?.rootViewController, withAlertTitle: ALERT_TITLE, buttonOkTitle: ALERT_OK, andMessage: response["message"] as? String) { (action) in}
//            }
//        }
        
        
        //MARK: MULTIPART DATA
        let newParam : [String : Any] = [
            "name": "Jayesh",
            "email": "jayesh3@gmail.com",
            "birthdate": "01/01/2020",
            "contact": "9998887770",
            "description": "Test"
        ]
        let image =  #imageLiteral(resourceName: "img1.jpg")
        CommonWS.PostURLWithMultipart(url: USER_API, dict: newParam, imageData: image.pngData()!) {(response, status) in
            if status == 200
            {
                print(response as NSDictionary)
            }
            else
            {
                SingleTon.showAlertonView(self.view.window?.rootViewController, withAlertTitle: ALERT_TITLE, buttonOkTitle: ALERT_OK, andMessage: response["message"] as? String) { (action) in}
            }
        }
    }
     //MARK:- GET DATA
    @IBAction func getUsers(_ sender: Any) {
        let newParam : [String : Any] = [:]
        CommonWS.GetURL(url: USER_API, dict: newParam) {(response, status) in
            if status == 200
            {
                print(response as NSDictionary)
            }
            else
            {
                SingleTon.showAlertonView(self.view.window?.rootViewController, withAlertTitle: ALERT_TITLE, buttonOkTitle: ALERT_OK, andMessage: response["message"] as? String) { (action) in}
            }
        }
    }
}

