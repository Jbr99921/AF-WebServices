//
//  Constants.swift
//  DLScanner
//
//  Created by Jayesh Thummar on 26/02/19.
//  Copyright © 2019 bacancy. All rights reserved.
//

import Foundation
import UIKit

//MARK:- App delegate
let DocumentPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]


//MARK:- APIs and URL gor Google cloud Vision
//let MAIN_URL = "http://192.168.1.71:3002/" // Loccal URL
let MAIN_URL = "https://ios-interview-test.herokuapp.com/" // Live URL

//MARK:- EndPoints
//used
let USER_API = "users"

//MARK:- Alert title, messages and buttons
let ALERT_TITLE = "DLScanner"
let ALERT_OK = "Ok"
let ALERT_CANCEL = "Cancel"
let ALERT_DELETE = "Delete"
let ALERT_EDIT = "Edit"
let ALERT_SAVE = "Save"
let ALERT_DONE = "Done"
let ALERT_YES = "YES"
let ALERT_NO = "No"
let ALERT_SETTINGS = "Settings"
let ALERT_COPY = "Copy"
let ALERT_OPEN = "Open"

let INTERNET_ERROR = "You are browsing offline. Please check your internet connection!"
let ERROR = "Opps! Something went wrong."
